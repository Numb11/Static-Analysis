<?php
/**
 * config.php
 *
 * This file establishes a secure connection to the MySQL database using PDO.
 * It should be included in other PHP files where database access is needed.
 */

// Database credentials – update these with your actual values.
$host    = 'localhost';          // e.g., 'localhost'
$port = '8889';
$db      = 'secure_software'; // Replace with your database name
$user    = 'root';   // Replace with your database username
$pass    = 'root';   // Replace with your database password
$charset = 'utf8mb4';            // Recommended charset

// Construct the Data Source Name (DSN)
$dsn = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";

// PDO options for enhanced security and error handling.
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // Throw exceptions on errors.
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,       // Fetch results as associative arrays.
    PDO::ATTR_EMULATE_PREPARES   => false,                  // Use native prepared statements.
];

try {
    // Create a new PDO instance.
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    // If the connection fails, exit with an error message.
    die("Database connection failed: " . $e->getMessage());
}
?>